import { Component, OnInit, Input } from '@angular/core';
import { RepositoryService } from "../../services/repository.service"
import {Router} from "@angular/router"

@Component({
  selector: 'app-posts-list',
  templateUrl: './posts-list.component.html',
  styleUrls: ['./posts-list.component.css']
})
export class PostsListComponent implements OnInit {
 @Input() modelObj: any;
  postModelObj: any
  allPosts: any;
  postDisplayed: any;

  constructor(private RepositorySVC: RepositoryService, private router:Router) {
    this.allPosts = [];
  }

  ngOnInit() {
    this.postModelObj = {
      title: this.modelObj.title,
      text_alone: this.modelObj.descritpion
    }

    this.RepositorySVC.getAllProducts().subscribe(
      data => {
        this.allPosts = data.map(subdata => {
         let itemToReturn=subdata.acf;
         itemToReturn.slug=subdata.slug
          return itemToReturn
        });
        this.postDisplayed = this.allPosts;

        console.log(data);
      })
  }
  get filters() {
    return this.allPosts.map(data => data.category)
  }

  filterBy(typeOfReal: string) {
    if (typeOfReal == 'none') this.postDisplayed = this.allPosts;
    else this.postDisplayed = this.allPosts.filter(obj => obj.category == typeOfReal)
  }

  goToItem(item){
      let url="/realisation/"+item.slug;
  this.router.navigate([url])
 
  }

}
