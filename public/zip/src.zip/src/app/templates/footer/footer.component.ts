import { Component, Input, OnInit, HostListener } from '@angular/core';
import { RepositoryService } from "../../services/repository.service"

@Component({
  selector: 'app-footer',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.css']
})
export class FooterComponent implements OnInit {
  private idMenu = 127
  public content: any;
  logoCompany: any;
  private isMobile: boolean;
  public innerWidth;
  private links:any;

  constructor(private _Repo: RepositoryService) {
    this.innerWidth = window.innerWidth;
    this.content = {};
  }

  ngOnInit() {
    this.onResize();
    this._Repo.getMenuById(this.idMenu).subscribe(
      data => {
        this.content = data.acf.footer;
        this.logoCompany = data.acf.logo_company_footer;
        this.links=data.acf.footer_links;
      }
    )
  }
  @HostListener('window:resize', ['$event'])
  onResize(event?) {
    let innerW = event == undefined ? window.innerWidth : event.target.innerWidth;
    if (innerW < 800) {
      this.isMobile = true;

    }
    else this.isMobile = false
  }

}
