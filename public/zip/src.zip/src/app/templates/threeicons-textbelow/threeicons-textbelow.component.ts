import { Component, Input,OnInit } from '@angular/core';

@Component({
  selector: 'app-threeicons-textbelow',
  templateUrl: './threeicons-textbelow.component.html',
  styleUrls: ['./threeicons-textbelow.component.css']
})
export class ThreeiconsTextbelowComponent implements OnInit {
@Input() modelObj
  constructor() {
}

ngOnInit(){
  console.log(this.modelObj);
}
}
