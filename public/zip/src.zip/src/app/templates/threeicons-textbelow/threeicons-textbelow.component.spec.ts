/* tslint:disable:no-unused-variable */
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { DebugElement } from '@angular/core';

import { ThreeiconsTextbelowComponent } from './threeicons-textbelow.component';

describe('ThreeiconsTextbelowComponent', () => {
  let component: ThreeiconsTextbelowComponent;
  let fixture: ComponentFixture<ThreeiconsTextbelowComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ThreeiconsTextbelowComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ThreeiconsTextbelowComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
