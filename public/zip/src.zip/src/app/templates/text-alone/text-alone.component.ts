import { Component, OnInit,Input } from '@angular/core';

@Component({
  selector: 'app-text-alone',
  templateUrl: './text-alone.component.html',
  styleUrls: ['./text-alone.component.css']
})
export class TextAloneComponent implements OnInit {
@Input() modelObj:any;
  constructor() { }

  ngOnInit() {
  }

}
