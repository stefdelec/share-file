/* tslint:disable:no-unused-variable */
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { DebugElement } from '@angular/core';

import { TextAloneComponent } from './text-alone.component';

describe('TextAloneComponent', () => {
  let component: TextAloneComponent;
  let fixture: ComponentFixture<TextAloneComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TextAloneComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TextAloneComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
