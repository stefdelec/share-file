import { Component, OnInit, Input, HostListener, Inject } from '@angular/core';
import { RepositoryService } from "../../services/repository.service"
import { DOCUMENT } from "@angular/platform-browser"
@Component({
  selector: 'app-menu',
  templateUrl: './menu.component.html',
  styleUrls: ['./menu.component.css']
})
export class MenuComponent implements OnInit {
  @Input() modelObj: any;
  private idMenu = 127
  public Content: any;
  public menuRight: any;
  private socialNetwork: any
  private phonenumber: any;
  private contactIcone: any;
  private languageMenuShow: boolean
  public innerWidth;
  public logoCompany: any;
  private isMobile: any;
  private menuShown: boolean;
  constructor(private _Repo: RepositoryService) {
    this.innerWidth = window.innerWidth;
    this.languageMenuShow = true;
    this.menuShown = false;
  }

  @HostListener("window:scroll", ['$event'])
  menuReset($event: Event) {
    let number = document.body.scrollTop;
    if (number > 100) {
      this.languageMenuShow = false;
    }
    else {
      this.languageMenuShow = true;

    }
  }
  @HostListener('window:resize', ['$event'])
  onResize(event?) {
    let innerW = event == undefined ? window.innerWidth : event.target.innerWidth;
    if (innerW < 1315) {
      this.isMobile = true;

    }
    else this.isMobile = false
  }

  ngOnInit() {
    this.onResize();
    this._Repo.getMenuById(this.idMenu).subscribe(
      data => {
        this.logoCompany = data.acf.logo_company;
        this.contactIcone = data.acf.contact_icone[0];
        this.phonenumber = data.acf.phone_number;
        this.socialNetwork = data.acf.reseaux_sociaux;
        this.Content = data.acf.menu;
        this.menuRight = data.acf.menu_rightside;

      }

    )
  }

}
