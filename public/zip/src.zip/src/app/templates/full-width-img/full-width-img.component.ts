import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-full-width-img',
  templateUrl: './full-width-img.component.html',
  styleUrls: ['./full-width-img.component.css']
})
export class FullWidthImgComponent {
@Input() modelObj:any;
  constructor() { }


}
