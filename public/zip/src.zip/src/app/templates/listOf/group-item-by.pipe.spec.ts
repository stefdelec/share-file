/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { GroupItemByPipe } from './group-item-by.pipe';

describe('GroupItemByPipe', () => {
  it('create an instance', () => {
    const pipe = new GroupItemByPipe();
    expect(pipe).toBeTruthy();
  });
});
