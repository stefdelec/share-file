import { Component, OnInit,Input } from '@angular/core';

@Component({
  selector: 'app-simple-list-grid',
  templateUrl: './simple-list-grid.component.html',
  styleUrls: ['./simple-list-grid.component.css']
})
export class SimpleListGridComponent implements OnInit {
@Input() modelObj;

  constructor() { }

  ngOnInit() {
    console.log(this.modelObj)
  }

}
