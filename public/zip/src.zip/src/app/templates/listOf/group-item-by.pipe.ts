import { Pipe, PipeTransform } from '@angular/core';
import * as _ from "lodash";

@Pipe({
  name: 'groupItemBy'
})
export class GroupItemByPipe implements PipeTransform {

  transform(arr: any[], args?: number): any {
    console.log(_.chunk(arr,args))
    return _.chunk(arr,args);
  }

}
