import { Component, OnInit,Input } from '@angular/core';

@Component({
  selector: 'app-list-manager',
  templateUrl: './list-manager.component.html',
  styleUrls: ['./list-manager.component.css']
})
export class ListManagerComponent implements OnInit {
@Input() modelObj;
  constructor() { }

  ngOnInit() {
  }

}
