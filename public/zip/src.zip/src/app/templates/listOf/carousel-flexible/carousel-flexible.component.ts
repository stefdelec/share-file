import { Component, Input, HostListener } from '@angular/core';
import { Router } from "@angular/router"
@Component({
  selector: 'app-carousel-flexible',
  templateUrl: './carousel-flexible.component.html',
  styleUrls: ['./carousel-flexible.component.css']
})
export class CarouselFlexibleComponent {
  @Input() modelObj;
  private isMobile: boolean;

  constructor(private router: Router) {
    console.log(this.modelObj)
    console.log("felxible");
    this.onResize()
  }
  @HostListener('window:resize', ['$event'])
  onResize(event?) {
    let innerW = event == undefined ? window.innerWidth : event.target.innerWidth;
    if (innerW < 900) {
      this.isMobile = true;

    }
    else this.isMobile = false
  }
  private navigateToProduct(item) {
    let url = "/" + item.link.post_type + "/" + item.link.post_name;

    this.router.navigate([url])

  }
}
