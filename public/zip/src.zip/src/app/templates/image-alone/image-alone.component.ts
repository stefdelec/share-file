import { Component, OnInit,Input } from '@angular/core';

@Component({
  selector: 'app-image-alone',
  templateUrl: './image-alone.component.html',
  styleUrls: ['./image-alone.component.css']
})
export class ImageAloneComponent implements OnInit {
@Input() modelObj;
  constructor() { }

  ngOnInit() {
  }

}
