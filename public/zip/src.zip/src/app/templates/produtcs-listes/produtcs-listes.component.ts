import { Component, OnInit, Input } from '@angular/core';
import { RepositoryService } from "../../services/repository.service"
import { Router } from "@angular/router"

@Component({
  selector: 'app-produtcs-listes',
  templateUrl: './produtcs-listes.component.html',
  styleUrls: ['./produtcs-listes.component.css']
})
export class ProdutcsListesComponent implements OnInit {
  private listOfdinettes: any;
  @Input() modelObj
  constructor(private RepositorySVC: RepositoryService, private router: Router) {

  }

  ngOnInit() {
    this.RepositorySVC.getAllProducts().subscribe(data => {
      this.listOfdinettes = data;
      console.log(data);
    })
  }

  goToItem(item) {
    console.log(item)
    let url = "/dinette/" + item.slug;
    this.router.navigate([url])

  }
}
