import { Component, OnInit,Input } from '@angular/core';

@Component({
  selector: 'app-button-alone',
  templateUrl: './button-alone.component.html',
  styleUrls: ['./button-alone.component.css']
})
export class ButtonAloneComponent implements OnInit {
@Input() modelObj
  constructor() {
    
   }

  ngOnInit() {
  }

}
