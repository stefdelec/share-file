import { Component, OnInit, Input } from '@angular/core';
import { RepositoryService } from "../../services/repository.service"
import {Router} from "@angular/router"

@Component({
  selector: 'app-realisation-filter',
  templateUrl: './realisation-filter.component.html',
  styleUrls: ['./realisation-filter.component.css']
})
export class RealisationFilterComponent implements OnInit {
  @Input() modelObj: any;
  realisationModelObj: any
  allRealisation: any;
  realisationDisplayed: any;

  constructor(private RepositorySVC: RepositoryService, private router:Router) {
    this.allRealisation = [];
  }

  ngOnInit() {
    this.realisationModelObj = {
      title: this.modelObj.title,
      text_alone: this.modelObj.descritpion
    }

    this.RepositorySVC.getAllRealisations().subscribe(
      data => {
        this.allRealisation = data.map(subdata => {
         let itemToReturn=subdata.acf;
         itemToReturn.slug=subdata.slug
          return itemToReturn
        });
        this.realisationDisplayed = this.allRealisation;

        console.log(data);
      })
  }
  get filters() {
    return this.allRealisation.map(data => data.category)
  }

  filterBy(typeOfReal: string) {
    if (typeOfReal == 'none') this.realisationDisplayed = this.allRealisation;
    else this.realisationDisplayed = this.allRealisation.filter(obj => obj.category == typeOfReal)
  }

  goToItem(item){
      let url="/realisation/"+item.slug;
  this.router.navigate([url])
 
  }

}
