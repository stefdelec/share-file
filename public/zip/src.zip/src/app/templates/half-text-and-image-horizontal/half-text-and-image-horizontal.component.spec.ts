/* tslint:disable:no-unused-variable */
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { DebugElement } from '@angular/core';

import { HalfTextAndImageHorizontalComponent } from './half-text-and-image-horizontal.component';

describe('HalfTextAndImageHorizontalComponent', () => {
  let component: HalfTextAndImageHorizontalComponent;
  let fixture: ComponentFixture<HalfTextAndImageHorizontalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HalfTextAndImageHorizontalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HalfTextAndImageHorizontalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
