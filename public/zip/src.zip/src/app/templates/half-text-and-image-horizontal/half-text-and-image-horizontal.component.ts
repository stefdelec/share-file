import { Component, Input, HostListener } from '@angular/core';

@Component({
  selector: 'app-half-text-and-image-horizontal',
  templateUrl: './half-text-and-image-horizontal.component.html',
  styleUrls: ['./half-text-and-image-horizontal.component.css']
})
export class HalfTextAndImageHorizontalComponent {
  @Input() modelObj: any;
  private isMobile: boolean
  private height: number;
  constructor() {

    this.onResize()
   }

  @HostListener('window:resize', ['$event'])
  onResize(event?) {
  let innerW= event==undefined?window.innerWidth :event.target.innerWidth;
    if (innerW < 1200) {
      this.isMobile = true;
      
    }
    else this.isMobile = false

    console.log(this.isMobile)
  }
}
