import { Component, OnInit, Input } from '@angular/core';
import { NgbCarouselConfig } from '@ng-bootstrap/ng-bootstrap';
import { Router } from "@angular/router"
@Component({
  selector: 'app-carousel',
  templateUrl: './carousel.component.html',
  styleUrls: ['./carousel.component.css']
})
export class CarouselComponent implements OnInit {
  @Input() modelObj: any;
  constructor(config: NgbCarouselConfig, private router: Router) {
    config.interval = 99999;
  }

  ngOnInit() {
  }
  private navigateToProduct(item) {
    let url = "/" + item.link.post_type + "/" + item.link.post_name;

    this.router.navigate([url])

  }
  navigateTo(item) {
    console.log(item);
    let itemLink=item.buttonlink;
    let url = "/" + itemLink.post_type + "/" + itemLink.post_name;

    this.router.navigate([url])

  }
}
