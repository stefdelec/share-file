import { Injectable } from '@angular/core';
import { Http, Response } from '@angular/http';
import 'rxjs/Rx';

@Injectable()
export class RepositoryService {
  private baseUrl: string = "http://www.dinettes.fr/";
  private urlRequest: string = "wp-json/wp/v2/"
  private urlJson: string;
  constructor(private http: Http) {
    this.urlJson = this.baseUrl + this.urlRequest;


  }

  public getPostBySlug(slug: string) {
    return this.http.get(this.urlJson + 'posts?slug=' + slug).map(data => data.json());

  }
    public getPostById(id: number) {
    return this.http.get(this.urlJson + 'posts/' + id).map(data => data.json());

  }
  
  public getPageBySlud(slug: string) {
    return this.http.get(this.urlJson + 'pages?slug=' + slug).map(data => data.json());

  }

  public getAllRealisations() {
    return this.http.get(this.urlJson + 'realisation-api/').map(data => data.json());

  }

  public getAllProducts() {
    return this.http.get(this.urlJson + 'dinette-api/').map(data => data.json());

  }
  public getRealisationBySlug(slug: string) {
    return this.http.get(this.urlJson + 'realisation-api?slug=' + slug).map(data => data.json());

  }
  public getRealisationById(id: number) {
    return this.http.get(this.urlJson + 'realisation-api/' + id).map(data => data.json());

  }
  public getPageByParentId(id: number) {
    return this.http.get(this.urlJson + 'pages?parent=' + id).map(data => data.json());

  }
  public getPageByParentTitle(title: string) {
    return this.http.get(this.urlJson + 'pages?title=' + title).map(data => data.json());

  }
  public getPageById(id: number) {
    return this.http.get(this.urlJson + 'pages/' + id).map(data => data.json());

  }

  public getProductById(id: number) {
    return this.http.get(this.urlJson + 'Dinette-api/' + id).map(data => data.json());

  }
  public getProductBySlug(slug: string) {
    return this.http.get(this.urlJson + 'dinette-api?slug=' + slug).map(data => data.json());

  }
  public getMenuById(id: number) {
    return this.http.get(this.urlJson + 'menu-api/' + id).map(data => data.json());

  }


  public isExist(data) {

  }

}

