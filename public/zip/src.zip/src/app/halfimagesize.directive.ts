import { Directive, ElementRef, OnInit, Input } from '@angular/core';

@Directive({
  selector: '[appHalfimagesize]'
})
export class HalfimagesizeDirective implements OnInit {
  @Input() HalfimagesizeDirective;

  constructor(private el: ElementRef) {
    console.log(this.el);

  }
  ngOnInit() {

    //  this.el.nativeElement.style.width=this.el.nativeElement.style.height/2;
    this.el.nativeElement.style.position = 'absolute';
    this.el.nativeElement.style.left = '50%';
    this.el.nativeElement.style["margin-left"] = this.el.nativeElement.style.width / 2;
  }
}
