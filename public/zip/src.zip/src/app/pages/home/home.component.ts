import { Component, OnInit } from '@angular/core';
import { RepositoryService } from "../../services/repository.service"
import { Router, ActivatedRoute, Params } from "@angular/router"
import 'rxjs/add/operator/switchMap';


@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  Content: any = [];
  private id = 66;
  constructor(private _Repo: RepositoryService, private route: ActivatedRoute, private router: Router) {
    


  }


  ngOnInit() {
    this._Repo.getPageById(this.id).subscribe(data => {
      this.Content = data.acf.pagemodules
    })

  }


  // else if (this.route.snapshot.url[0].path == "product") {
  //   return this._Repo.getProductById(params['id'])
  // }


}


