import { Component, OnInit } from '@angular/core';
import { RepositoryService } from "../../services/repository.service"
import { Router, ActivatedRoute, Params } from "@angular/router"
import 'rxjs/add/operator/switchMap';

@Component({
  selector: 'app-post',
  templateUrl: './post.component.html',
  styleUrls: ['./post.component.css']
})
export class PostComponent implements OnInit {
  Content: any = [];
  constructor(private _Repo: RepositoryService, private route: ActivatedRoute, private router: Router) {

  }

  ngOnInit() {
    this.route.params.subscribe(params => {
      this._Repo.getPostById(params['id']).subscribe(data => {
        this.Content = data.acf.pagemodules
      })

    })
  }
}
