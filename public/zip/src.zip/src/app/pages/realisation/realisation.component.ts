import { Component, OnInit } from '@angular/core';
import { RepositoryService } from "../../services/repository.service"
import { Router, ActivatedRoute, Params } from "@angular/router"
import 'rxjs/add/operator/switchMap';

@Component({
  selector: 'app-realisation',
  templateUrl: './realisation.component.html',
  styleUrls: ['./realisation.component.css']
})
export class RealisationComponent implements OnInit {
  Content: any = [];
  constructor(private _Repo: RepositoryService, private route: ActivatedRoute, private router: Router) {

  }

  ngOnInit() {

    this.route.params.subscribe(params => {
      this._Repo.getRealisationBySlug(params['slug']).subscribe(data => {
        this.Content = data[0].acf.pagemodules
      })

    })
  }


}
