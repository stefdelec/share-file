import { Component, OnInit } from '@angular/core';
import { Http } from "@angular/http"
import { FormBuilder, FormGroup, Validators } from '@angular/forms';


@Component({
  selector: 'app-contact',
  templateUrl: './contact.component.html',
  styleUrls: ['./contact.component.css']
})
export class ContactComponent implements OnInit {
  private contactForm: FormGroup;
  private robotQuestion: any;
  private isRobot: any;
  private statusCode: boolean;
  constructor(private _http: Http, private FB: FormBuilder) {
    this.isRobot = [
      {
        expectedAnswer: true,
        sentense: "Je suis un humain"
      },
      {
        expectedAnswer: false,
        sentense: "Je suis un robot"
      },
      {
        expectedAnswer: true,
        sentense: "Je ne suis pas un robot"
      },
      {
        expectedAnswer: false,
        sentense: "Je ne suis pas un humain"
      }
    ];
    this.robotQuestion = this.isRobot[Math.floor(Math.random() * (this.isRobot.length)) ]
  }

  ngOnInit() {
    this.contactForm = this.FB.group({
      name: ["", Validators.required],
      surname: ["", Validators.required],
      company: [""],
      phonenumber: [""],
      email: ["", Validators.required],
      address: [""],
      postalcode: [""],
      city: [""],
      formControlName: [""],
      country: [""],
      comment: [""],
      isRobot: [""]

    });
  }

  get isNotRobot() {
    return this.contactForm.controls["isRobot"].value == this.robotQuestion.expectedAnswer;
  }

  onSubmit(event) {
    // console.log(this.contactForm.status);
    console.log(this.isNotRobot);
    if (this.contactForm.status == "VALID" && this.isNotRobot) {

      this._http.post("https://dinettes.fr/wp-json/custom-endpoint/v1/sendcontactform", this.contactForm.value).subscribe(data => {
        console.log(data.status);
        if (data.status == 200) {
          this.statusCode = true;
        }
      });
    }
  }

}
