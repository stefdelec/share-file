import { Component, OnInit } from '@angular/core';
import { RepositoryService } from "../../services/repository.service"
import { Router, ActivatedRoute, Params } from "@angular/router"
import 'rxjs/add/operator/switchMap';
@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent implements OnInit {
  Content: any = [];
  constructor(private _Repo: RepositoryService, private route: ActivatedRoute, private router: Router) {

  }

  ngOnInit() {
    this.route.params.subscribe(params => {
      this._Repo.getProductBySlug(params['slug']).subscribe(data => {
        console.log(data.acf);
        this.Content = data[0].acf.pagemodules
      })

    })
  }

}
