import { Component, OnInit } from '@angular/core';
import { RepositoryService } from "../../services/repository.service"
import { Router, ActivatedRoute, Params } from "@angular/router"
import 'rxjs/add/operator/switchMap';



@Component({
  selector: 'app-pages',
  templateUrl: './pages.component.html',
  styleUrls: ['./pages.component.css']
})
export class PagesComponent implements OnInit {

  Content: any = [];
  private id = 66;
  constructor(private _Repo: RepositoryService, private route: ActivatedRoute, private router: Router) { }

  ngOnInit() {
    this.route.params.subscribe(params => {
      this._Repo.getPageBySlud(params["slug"]).subscribe(data => {
        this.Content = data[0].acf.pagemodules 
      })
    })
  }
}
