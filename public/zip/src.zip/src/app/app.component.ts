import { Component, HostListener, OnInit } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'app works!';
  private isMobile

  ngOnInit() {
    this.onResize()
  }
  @HostListener('window:resize', ['$event'])
  onResize(event?) {
    let innerW = event == undefined ? window.innerWidth : event.target.innerWidth;
    if (innerW < 1315) {
      this.isMobile = true;

    }
    else this.isMobile = false
  }
}
