/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { HalfimagesizeDirective } from './halfimagesize.directive';

describe('HalfimagesizeDirective', () => {
  it('should create an instance', () => {
    const directive = new HalfimagesizeDirective();
    expect(directive).toBeTruthy();
  });
});
