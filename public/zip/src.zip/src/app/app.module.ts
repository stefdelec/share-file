import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule,ReactiveFormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { RouterModule, Routes } from "@angular/router"
//NG2 bootstrap
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';

import { AppComponent } from './app.component';
import { HomeComponent } from './pages/home/home.component';
import { CarouselComponent } from './templates/carousel/carousel.component';
import { FooterComponent } from './templates/footer/footer.component';
import { HeaderComponent } from './templates/header/header.component';
import { TitleComponent } from './templates/title/title.component';
import { HalfTextAndImageHorizontalComponent } from './templates/half-text-and-image-horizontal/half-text-and-image-horizontal.component';
import { MenuComponent } from './templates/menu/menu.component';
import { MainComponent } from './templates/main/main.component';

//service
import { RepositoryService } from "./services/repository.service";
import { FullWidthImgComponent } from './templates/full-width-img/full-width-img.component';
import { ThreeiconsTextbelowComponent } from './templates/threeicons-textbelow/threeicons-textbelow.component';
import { ListManagerComponent } from './templates/listOf/list-manager/list-manager.component';
import { CarouselFlexibleComponent } from './templates/listOf/carousel-flexible/carousel-flexible.component';
import { SimpleListGridComponent } from './templates/listOf/simple-list-grid/simple-list-grid.component';
import { GroupItemByPipe } from './templates/listOf/group-item-by.pipe';
import { HrComponent } from './templates/hr/hr.component';
import { ProductComponent } from './pages/product/product.component';
import { RealisationComponent } from './pages/realisation/realisation.component';
import { ButtonAloneComponent } from './templates/button-alone/button-alone.component';
import { TextAloneComponent } from './templates/text-alone/text-alone.component';
import { ImageAloneComponent } from './templates/image-alone/image-alone.component';
import { PagesComponent } from './pages/pages/pages.component';
import { HalfimagesizeDirective } from './halfimagesize.directive';
import { RealisationFilterComponent } from './templates/realisation-filter/realisation-filter.component';
import { ProdutcsListesComponent } from './templates/produtcs-listes/produtcs-listes.component';
import { ContactComponent } from './pages/contact/contact.component';
import { VideoComponent } from './templates/video/video.component';
import { PostComponent } from './pages/post/post.component';
import { PostsListComponent } from './templates/posts-list/posts-list.component';

const appRoutes: Routes = [
  {
    path: "page/contact",
    component: ContactComponent
  },
  {
    path: "home",
    component: HomeComponent
  },
  {
    path: "page/:slug",
    component: PagesComponent

  },
  {
    path: "dinette/:slug",
    component: ProductComponent
  },
  {
    path: "product/:id",
    component: ProductComponent
  },
  {
    path: "realisation/:slug",
    component: RealisationComponent
  },
  {
    path: "blog/:id",
    component: PostComponent
  },
  {
    path: "",
    redirectTo: "home",
    pathMatch: 'full'
  }
]


@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    CarouselComponent,
    FooterComponent,
    HeaderComponent,
    TitleComponent,
    HalfTextAndImageHorizontalComponent,
    MenuComponent,
    MainComponent,
    FullWidthImgComponent,
    ThreeiconsTextbelowComponent,
    ListManagerComponent,
    CarouselFlexibleComponent,
    SimpleListGridComponent,
    GroupItemByPipe,
    HrComponent,
    ProductComponent,
    RealisationComponent,
    ButtonAloneComponent,
    TextAloneComponent,
    ImageAloneComponent,
    PagesComponent,
    HalfimagesizeDirective,
    RealisationFilterComponent,
    ProdutcsListesComponent,
    ContactComponent,
    VideoComponent,
    PostComponent,
    PostsListComponent,
  ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    HttpModule,
    RouterModule.forRoot(appRoutes),
    NgbModule.forRoot()
  ],
  providers: [RepositoryService],
  bootstrap: [AppComponent]
})
export class AppModule { }
